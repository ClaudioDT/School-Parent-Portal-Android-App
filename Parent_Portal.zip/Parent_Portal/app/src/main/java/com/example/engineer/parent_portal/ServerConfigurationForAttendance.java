package com.example.engineer.parent_portal;

/**
 * Created by Engineer on 25/05/2017.
 */

public class ServerConfigurationForAttendance {


}
