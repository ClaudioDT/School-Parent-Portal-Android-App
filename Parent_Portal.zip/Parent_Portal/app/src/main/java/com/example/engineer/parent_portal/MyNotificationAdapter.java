package com.example.engineer.parent_portal;

/**
 * Created by Engineer on 29/05/2017.
 */

public class MyNotificationAdapter {

    String notify_name;
    String notify_date;
    String notify_description;




    public String getNotify_name() {
        return notify_name;
    }

    public void setNotify_name(String notify_name) {
        this.notify_name = notify_name;
    }

    public String getNotify_date() {
        return notify_date;
    }

    public void setNotify_date(String notify_date) {
        this.notify_date = notify_date;
    }

    public String getNotify_description() {
        return notify_description;
    }

    public void setNotify_description(String notify_description) {
        this.notify_description = notify_description;
    }
}
