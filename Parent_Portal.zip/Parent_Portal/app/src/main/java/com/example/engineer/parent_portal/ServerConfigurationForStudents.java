package com.example.engineer.parent_portal;

/**
 * Created by Engineer on 04/06/2017.
 */

public class ServerConfigurationForStudents {

    public static final String Data_Url ="http://192.168.43.183/DemoStudentsPanel/GetStudents.php?parent_email=";
    public static final String key_std_num ="std_num";
    public static final String key_student_name ="stdName";
    public static final String key_student_surname ="stdSurname";
    public static final String key_student_email ="stdEmail";
    public static final String key_student_grade ="stdGrade";
    public static final String key_parent_name ="prtName";
    public static final String key_parent_address ="prtAddress";
    public static final String key_parent_email ="prtEmail";
    public static final String key_parent_contact ="prtContact";
    public static final String Json_Array ="Results";
}
