package com.example.engineer.parent_portal;

/**
 * Created by Engineer on 09/06/2017.
 */

public class ServerConfigurationForNotification {
    //http://192.168.43.183/DemoStudentsPanel/jsonData.php"
    public static final String key_URL = "http://192.168.43.183/DemoStudentsPanel/jsonData.php";
    public static final String key_name = "notify_name";
    public static final String key_date = "notify_date";
    public static final String key_descrption = "notify_description";
}
