package com.example.engineer.parent_portal;

/**
 * Created by Engineer on 08/06/2017.
 */

public class ServerConfigurationForReports {

    public static final String Data_Url    ="http://192.168.43.183/DemoStudentsPanel/GetReport.php?std_number=";
    public static final String key_std_num ="ID";
    public static final String key_name    ="Name";
    public static final String key_surname ="Surname";
    public static final String key_mark_1  ="Mark_1";
    public static final String key_mark_2  ="Mark_2";
    public static final String key_mark_3  ="Mark_3";
    public static final String Json_Array  ="Results";
}
